@echo off
title NoobTalk Desktop Client
cd /d "%~dp0"

java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Java is not installed.
    goto :failed
)

java -version 2>&1 | find "17" >nul
if %errorlevel% neq 0 (
    echo [ERROR] Java 17+ is required.
    java -version
    goto :failed
)

set "JAR=%~dp0bin\client-desktop.jar"
if not exist "%JAR%" (
    echo [ERROR] %JAR% not found after build.
    goto :failed
)

echo ==================================================
echo Starting client-desktop.jar
echo Config: bin\client.properties
echo Logs:   bin\logs\client-desktop.log
echo ==================================================
echo.

echo Launching GUI (no console window)...
start "NoobTalk Client" javaw -Dlog4j2.statusLoggerLevel=OFF -jar "%JAR%"
exit /b 0

:failed
exit /b 1
