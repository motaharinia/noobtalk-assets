@echo off
setlocal EnableDelayedExpansion
title NoobTalk Desktop Client
cd /d "%~dp0"

java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Java is not installed.
    goto :failed
)

java -version 2>&1 | find "17" >nul
if %errorlevel% neq 0 (
    echo [ERROR] Java 17+ is required.
    java -version
    goto :failed
)

set "BIN=%~dp0bin"
if not exist "%BIN%\" (
    echo [ERROR] bin\ folder not found beside run.bat
    goto :failed
)
set "JAR="
set "BEST_SCORE=-1"

pushd "%BIN%"
for %%F in (client-desktop*.jar) do (
    set "NAME=%%~nF"
    set "MAJOR=0"
    set "MINOR=0"
    set "PATCH=0"
    if /i not "!NAME!"=="client-desktop" (
        set "VER=!NAME:client-desktop-=!"
        for /f "tokens=1,2,3 delims=." %%a in ("!VER!") do (
            set "MAJOR=%%a"
            set "MINOR=%%b"
            set "PATCH=%%c"
        )
    )
    if not defined MAJOR set "MAJOR=0"
    if not defined MINOR set "MINOR=0"
    if not defined PATCH set "PATCH=0"
    set "SCORE=0"
    set /a SCORE=!MAJOR!*1000000+!MINOR!*1000+!PATCH! 2>nul
    if !SCORE! gtr !BEST_SCORE! (
        set /a BEST_SCORE=!SCORE!
        set "JAR=%%F"
    )
)
popd

if not defined JAR (
    echo [ERROR] No client-desktop*.jar found in bin\
    goto :failed
)
if not exist "%BIN%\!JAR!" (
    echo [ERROR] %BIN%\!JAR! not found.
    goto :failed
)
set "JAR=%BIN%\!JAR!"

for %%I in ("!JAR!") do set "JAR_NAME=%%~nxI"
echo ==================================================
echo Starting !JAR_NAME!
echo Config: bin\client.properties
echo Logs:   bin\logs\client-desktop.log
echo ==================================================
echo.

echo Launching GUI (no console window)...
start "NoobTalk Client" javaw -Dlog4j2.statusLoggerLevel=OFF -jar "!JAR!"
endlocal & exit /b 0

:failed
echo.
pause
endlocal & exit /b 1
