NoobTalk desktop — how to use the tunnel

================================================================================
Option 1: Firefox only + NoobTalk client (no Netch, no system-wide tunnel)
================================================================================

1. Run run-client.bat and click Connect. Wait until the client reports a successful
   WebSocket connection. Local SOCKS5 is then available on 127.0.0.1:1080.

2. Configure Firefox to use that proxy (screenshots in
   help\only firefox without windows tunnel\):
   - Settings → search "proxy" → Connection settings → Configure proxy
   - Manual proxy configuration
   - SOCKS host 127.0.0.1, port 1080, SOCKS v5
   - Enable "Proxy DNS when using SOCKS v5"
   - Leave "No proxy for" empty unless you need local exceptions

3. Open a website in Firefox. Traffic goes: Firefox → NoobTalk (1080) → tunnel.

4. To stop: disconnect the client or set Firefox back to "No proxy".

================================================================================
Option 2: All Windows + Netch + NoobTalk client (system-wide via Netch)
================================================================================

1. Run run-client.bat and click Connect first (before Netch). The client must be
   up on 127.0.0.1:1080 so Netch can reach the tunnel.

2. Install the netch module from the client Updates tab if needed, then open
   modules\netch\Netch.exe (or use Start on the netch module in the client).

3. In Netch:
   - Server: [SOCKS][NONE] NoobTalk-Local (127.0.0.1:1080)
   - Mode: [1] Global (between Git and Google Drive alphabetically; if missing,
     use menu Mode → Reload modes)
   - Click Start in Netch and approve UAC if prompted.

   Global mode sends handled processes through Netch into NoobTalk, but bypasses
   Netch itself and the NoobTalk client (java.exe / javaw.exe) so the tunnel does
   not loop through the local SOCKS proxy.

4. In Firefox (and other apps): use No proxy / system default — do not enable the
   manual SOCKS settings from Option 1. Netch redirects traffic at the OS level.

5. If you see "Detected proxy loop", connect the NoobTalk client before starting
   Netch. After changing mode files, use Mode → Reload modes or restart Netch.

6. To stop: stop Netch, then disconnect the client.
