1. Run run-client.bat and click Connect (wait for "WebSocket connected successfully")
2. Open Netch from noobtalk-client\Netch\Netch.exe (not a copy from another folder)
3. Server dropdown: [SOCKS][NONE] NoobTalk-Local
4. Mode dropdown: pick [1] Global (between Git and Google Drive alphabetically)
5. If Global is missing: top menu Mode -> Reload modes, then check the list again
6. Click Start

Global mode bypasses Netch itself and the NoobTalk Java client (java.exe/javaw.exe)
so the tunnel bootstrap is not sent back through the local SOCKS proxy.

After updating mode files, use top menu Mode -> Reload modes (or restart Netch).
If you still see "Detected proxy loop", connect the client before starting Netch.