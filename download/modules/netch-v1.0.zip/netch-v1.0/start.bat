@echo off
:: این خط باعث می‌شود مسیرِ جاری به مسیرِ فایلِ bat تغییر کند
cd /d "%~dp0"

:: بررسی وجود فایل
if not exist "Netch.exe" (
    echo [ERROR] 'Netch.exe' not found!
    pause
    exit /b
)

:: بررسی دسترسی ادمین (برای عملکرد خودکار)
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :run
) else (
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B
)

:run
start "" "Netch.exe" -d
exit