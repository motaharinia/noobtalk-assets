@echo off
cd /d "%~dp0"

exit